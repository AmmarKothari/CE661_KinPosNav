function pythagoreanLatLonDistance(lat1, lon1, lat2, lon1)
    % used this as an example
    % https://www.mathworks.com/matlabcentral/fileexchange/38812-latlon-distance

    



end